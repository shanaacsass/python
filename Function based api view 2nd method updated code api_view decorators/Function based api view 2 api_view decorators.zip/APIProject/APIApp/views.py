from django.shortcuts import render, HttpResponse
from .models import Article
from .serializers import ArticleSerializer

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
# Create your views here.
def Index(request):
    return HttpResponse("Hello Index")

@api_view(['GET','POST'])
def article_list(request):
    if request.method == 'GET':
        #if request.method == GET means we need to get all articles
        articles = Article.objects.all()
        print(articles)
        serializer = ArticleSerializer(articles, many=True)
        print(serializer.data)
        return Response(serializer.data)
        return HttpResponse('hello')
    
    elif request.method == 'POST':
        #elif request.method is post means we need to create new article
        #1st we need to get data from the client side and it will json format right so 
    
        print(request.data)
        serializer = ArticleSerializer(data=request.data)
        print(serializer.is_valid())
        if serializer.is_valid():
            serializer.save()
            return Response({"notify":"New Article created successfully","data":serializer.data},status=status.HTTP_201_CREATED)
        return Response({"error":serializer.errors},status=status.HTTP_400_BAD_REQUEST)
       
@api_view(['GET','PUT','DELETE'])
def article_details(request,pk):
    print(pk)
    if request.method == 'GET':
        article_id_url = pk
        #we need to get article based on article_id
        try:
            article = Article.objects.get(article_id=article_id_url)
        except Article.DoesNotExist:
            return Response({"Notify":f"the given article id: {article_id_url} is not exist in article table"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = ArticleSerializer(article)
        return Response({"Notify":serializer.data}, status=status.HTTP_200_OK)
    

    elif request.method == "PUT":
        #we need to update Article based on article_id_url which we pass on url 
        print(pk)
        article_id_url = pk
        try:
            article = Article.objects.get(article_id=article_id_url)
        except Article.DoesNotExist:
            return Response({"Notify":f"the article_id: {article_id_url} is not exist in article table"},status=status.HTTP_404_NOT_FOUND)
        
        # data = JSONParser().parse(request)
        print(request.data)
        serializer = ArticleSerializer(article,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"Notify":f"the article_id: {article_id_url} is updated successfully","data":serializer.data},status=status.HTTP_205_RESET_CONTENT)    
        return Response({"Notify":f"the error exist in serialization", "error":serializer.errors},status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == "DELETE":
        #we need to delete article based on article_id so first we need to article_id from url 
        article_id_url = pk

        try:
            article = Article.objects.get(article_id=article_id_url)
        except Article.DoesNotExist:
            return Response({"Notify":f"The article_id: {article_id_url} is not exist in article table"}, status=status.HTTP_404_NOT_FOUND)
        
        article.delete()
        return Response({"Notify":f"The article_id:{article_id_url} is deleted successfully"}, status=status.HTTP_204_NO_CONTENT)