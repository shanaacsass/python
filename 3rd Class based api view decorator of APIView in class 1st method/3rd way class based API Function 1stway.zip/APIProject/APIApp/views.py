from django.shortcuts import render, HttpResponse
from rest_framework.decorators import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Article
from .serializers import ArticleSerializer
# Create your views here.

def Index(request):
    return HttpResponse('it is index')


class article_list(APIView):
    def get(self,request):
        articles = Article.objects.all()
        serializer = ArticleSerializer(articles, many=True)
        return Response({"data":serializer.data})
    
    def post(self,request):
        serializer = ArticleSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"Notify":"The New Article created successfully","data":serializer.data},status=status.HTTP_201_CREATED)
        return Response({"Notify":"Error exist in serialization and it was not valid", "mainerror":serializer.errors},status=status.HTTP_400_BAD_REQUEST)
    
class article_details(APIView):

    def get(self,request,pk):
        article_id_url = pk
        try:
            article = Article.objects.get(article_id=article_id_url)
        except Article.DoesNotExist:
            return Response({"Notify":f"the article id: {article_id_url} is not exist in article table"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = ArticleSerializer(article)
        return Response({"data":serializer.data})
    
    def put(self,request,pk):
        article_id_url = pk
        try:
            article = Article.objects.get(article_id=article_id_url)
        except Article.DoesNotExist:
            return Response({"Notify":f"the given article_id: {article_id_url} is not exist in article table"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = ArticleSerializer(article,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"Notify":f"The article_id: {article_id_url} is updated successfully", "data":serializer.data}, status=status.HTTP_205_RESET_CONTENT)
        
        return Response({"Notify":"Error exist in serializer", "mainerror":serializer.errors},status=status.HTTP_400_BAD_REQUEST)
    

    def delete(self,request,pk):
        article_id_url = pk

        try:
            article = Article.objects.get(article_id= article_id_url)
        except Article.DoesNotExist:
            return Response({"Notify":f"The article_id: {article_id_url} is not exist in article table "}, status=status.HTTP_404_NOT_FOUND)
        
        article.delete()
        return Response({"Notify":f"The article_id: {article_id_url} is deleted successfully"}, status=status.HTTP_204_NO_CONTENT)
    
    
