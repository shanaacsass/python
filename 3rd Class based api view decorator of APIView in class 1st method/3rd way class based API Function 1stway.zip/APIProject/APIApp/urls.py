from django.urls import path 
from .views import Index, article_list, article_details

urlpatterns = [
    path('',Index),
    path('articles/',article_list.as_view()),
    path('articles/<int:pk>/',article_details.as_view()),
]