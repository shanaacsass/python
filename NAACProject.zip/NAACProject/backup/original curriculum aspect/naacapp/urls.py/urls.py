
from django.urls import path
from .views import Index, article_list, article_details, curriculum_aspect_list, curriculum_aspect_detail

urlpatterns = [
    path('', Index),
    path('articles/', article_list),
    path('articles/<int:pk>/', article_details),
    path('curriculum-aspects/', curriculum_aspect_list),
    path('curriculum-aspects/<int:pk>/', curriculum_aspect_detail),
]
