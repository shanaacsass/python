from django.shortcuts import render, HttpResponse
from .models import Article, CurriculumAspect
from .serializers import ArticleSerializer, CurriculumAspectSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework import viewsets

from datetime import datetime
# Create your views here.
def Index(request):
    return HttpResponse("It is index it was working")

#FUNCTION BASED API Views Decorators from rest_framework  @api_view

@api_view(['GET','POST'])
def article_list(request):
    if request.method == 'GET':
        articles = Article.objects.all()
        serializer = ArticleSerializer(articles, many=True)
        print(articles)
        return Response(serializer.data)
    
    elif request.method == 'POST':
        # data = JSONParser().parse(request)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
        serializer = ArticleSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    

@api_view(['GET','PUT','DELETE'])
def article_details(request,pk):
    
    try:
        article = Article.objects.get(pk=pk)
    except Article.DoesNotExist:
        return HttpResponse(status=status.HTTP_404_NOT_FOUND)
    
    if request.method == "GET":
        serializer = ArticleSerializer(article)
        return Response(serializer.data)
       
    
    elif request.method == "PUT":
        # data = JSONParser().parse(request)
        serializer =ArticleSerializer(article, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == "DELETE":
        article.delete()
        return Response({"message": f"Article with ID {pk} was deleted successfully"}, status=status.HTTP_204_NO_CONTENT)


class ArticleViewSet(viewsets.ModelViewSet):
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer

    def perform_create(self, serializer):
        # Handle file upload
        file_obj = self.request.data.get('file')
        if file_obj:
            filename = f"{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}_{file_obj.name}"
            serializer.validated_data['file'].name = filename
        serializer.save()

    def perform_update(self, serializer):
        # Handle file update
        file_obj = self.request.data.get('file')
        if file_obj:
            filename = f"{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}_{file_obj.name}"
            serializer.validated_data['file'].name = filename
        serializer.save()


# List and create CurriculumAspect objects
@api_view(['GET', 'POST'])
def curriculum_aspect_list(request):
    if request.method == 'GET':
        curriculum_aspects = CurriculumAspect.objects.all()
        # print(curriculum_aspects)
        serializer = CurriculumAspectSerializer(curriculum_aspects, many=True)
        return Response(serializer.data)
    
    elif request.method == 'POST':
        serializer = CurriculumAspectSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# Retrieve, update and delete CurriculumAspect objects
@api_view(['GET', 'PUT', 'DELETE'])
def curriculum_aspect_detail(request, pk):
    try:
        curriculum_aspect = CurriculumAspect.objects.get(pk=pk)
    except CurriculumAspect.DoesNotExist:
        return HttpResponse(status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'GET':
        serializer = CurriculumAspectSerializer(curriculum_aspect)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        serializer = CurriculumAspectSerializer(curriculum_aspect, data=request.data)
        print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
            
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == 'DELETE':
        curriculum_aspect.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)