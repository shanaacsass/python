from django.db import models

# Create your models here.
class Article(models.Model):
    title= models.CharField(max_length=100)
    description = models.TextField()

def __str__(self):
   return self.title


# Curriculum aspects 
class CurriculumAspect(models.Model):
    curriculum_aspect_id = models.AutoField(primary_key=True)
    description = models.CharField(max_length=2000, blank=True)  # Description of the curriculum aspect
    link_for_additional_info = models.CharField(max_length=50, blank=True)
    additional_information = models.CharField(max_length=50, blank=True)
    number_of_programs_introduced = models.PositiveIntegerField(null=True, blank=True)

    # Year-wise number of programs introduced
    year_wise_certificate_year1 = models.CharField(max_length=50, blank=True)
    year_wise_certificate_year2 = models.CharField(max_length=50, blank=True)
    year_wise_certificate_year3 = models.CharField(max_length=50, blank=True)
    year_wise_certificate_year4 = models.CharField(max_length=50, blank=True)
    year_wise_certificate_year5 = models.CharField(max_length=50, blank=True)

    # Corresponding values for each year
    year_wise_certificate_year1_value = models.CharField(max_length=50, blank=True)
    year_wise_certificate_year2_value = models.CharField(max_length=50, blank=True)
    year_wise_certificate_year3_value = models.CharField(max_length=50, blank=True)
    year_wise_certificate_year4_value = models.CharField(max_length=50, blank=True)
    year_wise_certificate_year5_value = models.CharField(max_length=50, blank=True)

    # Minutes of relevant Academic Council/BOS meetings
    minutes_description = models.CharField(max_length=100)
    # Details of the certificate/Diploma programs
    certificate_diploma_details = models.CharField(max_length=100)
    # Any additional information
    additional_information_description = models.CharField(max_length=100)


    # 1.1.3 Percentage of participation of full-time teachers in various bodies
    participation_percentage = models.CharField(max_length=200, null=True, blank=True)

    #1.1.3.1 Year-wise number of teachers participating in various bodies
    teachers_participating_year1 = models.CharField(max_length=200, null=True, blank=True)
    teachers_participating_year2 = models.CharField(max_length=200, null=True, blank=True)
    teachers_participating_year3 = models.CharField(max_length=200, null=True, blank=True)
    teachers_participating_year4 = models.CharField(max_length=200, null=True, blank=True)
    teachers_participating_year5 = models.CharField(max_length=200, null=True, blank=True)

    #1.1.3.1 Corresponding values for each year
    teachers_participating_year1_value = models.CharField(max_length=200, null=True, blank=True)
    teachers_participating_year2_value = models.CharField(max_length=200, null=True, blank=True)
    teachers_participating_year3_value = models.CharField(max_length=200, null=True, blank=True)
    teachers_participating_year4_value = models.CharField(max_length=200, null=True, blank=True)
    teachers_participating_year5_value = models.CharField(max_length=200, null=True, blank=True)

    # Details of participation of teachers in various bodies
    teachers_participation_details = models.CharField(max_length=200, null=True, blank=True)
    # Any additional information for teacher participation
    additional_information_teachers_participation = models.CharField(max_length=200, null=True, blank=True)


    #1.2 Academic flexibility
    #1.2.1 Percentage of new Courses introduced out of the total number of courses
    percentage_new_courses = models.CharField(max_length=200, null=True, blank=True)

    #1.2.1.1 Number of new courses introduced within the last five years
    number_new_courses_last_five_years = models.CharField(max_length=200, null=True, blank=True)

    # Minutes of relevant Academic Council/BOS meetings
    academic_meetings_minutes = models.CharField(max_length=200, null=True, blank=True)
    # Details of the new courses introduced
    academic_flexibility_new_courses_details = models.CharField(max_length=200, null=True, blank=True)
    # Any additional information for academic flexibility
    academic_flexibility_additional_information = models.CharField(max_length=200, null=True, blank=True)

    #
    #1.2.2 Percentage of programs in which Choice Based Credit System (CBCS)/Elective course system has been implemented
    cbcs_percentage = models.CharField(max_length=200, null=True, blank=True)
    #1.2.2.1 Number of programs in which CBCS/Elective course system implemented
    cbcs_programs_count = models.CharField(max_length=200, null=True, blank=True)

    # Name of the programs in which CBCS is implemented
    cbcs_programs_names = models.CharField(max_length=200, null=True, blank=True)
    # Minutes of relevant Academic Council/BOS meetings
    cbcs_academic_meetings_minutes = models.CharField(max_length=200, null=True, blank=True)
    # Any additional information for CBCS implementation
    cbcs_additional_information = models.CharField(max_length=200, null=True, blank=True)


    #1.2.3 Average percentage of students enrolled in subject related Certificate/Diploma programs/Add-on programs
    certificate_diploma_programs_percentage = models.CharField(max_length=200, null=True, blank=True)

    #1.2.3.1 Year-wise number of students enrolled in subject related Certificate/Diploma/Add-on programs
    students_enrolled_year1 = models.CharField(max_length=50, blank=True)
    students_enrolled_year2 = models.CharField(max_length=50, blank=True)
    students_enrolled_year3 = models.CharField(max_length=50, blank=True)
    students_enrolled_year4 = models.CharField(max_length=50, blank=True)
    students_enrolled_year5 = models.CharField(max_length=50, blank=True)

    # Corresponding values for each year
    students_enrolled_year1_value = models.CharField(max_length=50, blank=True)
    students_enrolled_year2_value = models.CharField(max_length=50, blank=True)
    students_enrolled_year3_value = models.CharField(max_length=50, blank=True)
    students_enrolled_year4_value = models.CharField(max_length=50, blank=True)
    students_enrolled_year5_value = models.CharField(max_length=50, blank=True)

    #1.4: Feedback System
    # 1.4.1 Structured feedback received from Students, Teachers, Employers, Alumni, and Parents for design and review of syllabus-Semester wise/ year-wise
    feedback_options = models.CharField(max_length=200, null=True, blank=True)

    # URL for stakeholder feedback report
    feedback_report_url = models.CharField(max_length=200, null=True, blank=True)
    # Any additional information
    additional_information_feedback = models.CharField(max_length=200, null=True, blank=True)
    # Action taken report of the Institution on feedback report as stated in the minutes of the Governing Council, Syndicate, Board of Management
    feedback_action_taken_report = models.CharField(max_length=200, null=True, blank=True)
    
    # 1.4.2 Feedback processes classification
    feedback_process_classification = models.CharField(max_length=200, null=True, blank=True)

    # URL for feedback report classification
    classification_feedback_report_url = models.CharField(max_length=200, null=True, blank=True)
    # Any additional information for feedback
    classification_additional_information_feedback = models.CharField(max_length=200, null=True, blank=True)


    def __str__(self):
        return f"Curriculum Aspect: {self.curriculum_aspect_id}"
