from django.contrib import admin
from .models import Article, CurriculumAspect
# Register your models here.
# 1st way
# admin.site.register(CurriculumAspect)

# 2ndway
@admin.register(Article)
class ArticleModel(admin.ModelAdmin):
    list_filter = ('title','description')
    list_display = ('title','description')

# CurriculumAspect tables register 
admin.site.register(CurriculumAspect)
# @admin.register(CurriculumAspect)
# class CurriculumAspectModel(admin.ModelAdmin):
#     list_filter = ('curriculum_aspect_id','description')
#     list_display = ('curriculum_aspect_id','description')