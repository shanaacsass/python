from rest_framework import serializers
from .models import Article, CurriculumAspect
from django.db.models.fields.files import FieldFile 

class ArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Article
        fields = '__all__'
'''
class CurriculumAspectSerializer(serializers.ModelSerializer):
    class Meta:
        model = CurriculumAspect
        fields = '__all__'
'''        
class CurriculumAspectSerializer(serializers.ModelSerializer):
    class Meta:
        model = CurriculumAspect
        fields = '__all__'    

    def create(self, validated_data):
        # Loop through all file fields
        for field_name, field_value in validated_data.items():
            # Check if the field is a FileField instance
            if isinstance(field_value, FieldFile):
                # If the field has data, serialize it to include the file name
                if field_value:
                    validated_data[field_name] = field_value.name
                else:
                    # If the field is empty, set it to None
                    validated_data[field_name] = None
        
        # Call the parent class's create method to create the instance
        return super().create(validated_data)

    