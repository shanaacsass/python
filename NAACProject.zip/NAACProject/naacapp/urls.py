
#1st method 
'''
from django.urls import path
from .views import Index, article_list, article_details, curriculum_aspect_list, curriculum_aspect_detail

urlpatterns = [
    path('', Index),
    path('articles/', article_list),
    path('articles/<int:pk>/', article_details),
    path('curriculum/', curriculum_aspect_list),
    path('curriculum/<int:pk>/', curriculum_aspect_detail),
]
'''

from django.urls import path
from .views import Index, curriculum_aspect_list, curriculum_aspect_detail

urlpatterns = [
    path('', Index),
   
    path('api/curriculum/', curriculum_aspect_list),
    path('api/curriculum/<int:pk>/', curriculum_aspect_detail),
]


#2nd class method url
'''
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import Index, ArticleViewSet, CurriculumViewSet
# CurriculumAspectsApi
# Create a router and register our viewsets with it
router = DefaultRouter()
router.register(r'articles', ArticleViewSet, basename='article')
router.register(r'curriculum',CurriculumViewSet, basename='curriculum')

# The API URLs are now determined automatically by the router
urlpatterns = [
    path('', Index),

    path('api/', include(router.urls)),
    # path('curriculum-aspects/', CurriculumAspectsApi.as_view(),name='curriculum_aspects'),
 
]


'''