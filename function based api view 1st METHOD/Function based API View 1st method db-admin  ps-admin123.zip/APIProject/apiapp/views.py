from django.shortcuts import render, HttpResponse
from .models import Article
from .serializers import ArticleSerializer
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
def Index(request):
    return HttpResponse("It is index page")

@csrf_exempt
def article_list(request):
    if request.method == 'GET':
        #we need to get all articles
        articles = Article.objects.all()
        # print(articles)
        serializer = ArticleSerializer(articles,many=True)
        print(serializer.data)
        return JsonResponse({"data":serializer.data},status=200)

    elif request.method == 'POST':
        # Post means we need to create new article
        data = JSONParser().parse(request)
        print(data)
        serializer = ArticleSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return JsonResponse({"Msg":serializer.data},status=201)
        return JsonResponse({"error":serializer.errors},status=400)
    

@csrf_exempt
def article_details(request,pk):

    if request.method== 'GET':

        article_id_url =pk
        try:
            article = Article.objects.get(article_id=article_id_url)
        except Article.DoesNotExist:
            return JsonResponse({"Msg": f"The given article_id: {article_id_url}does not exist in Article table"})
        
        serializer = ArticleSerializer(article)
        return JsonResponse({"data":serializer.data},status=200)
    
    elif request.method == 'PUT':
        article_id_url = pk
        # First check the article is exist in Artcile table or not based on article_id
        try:
            article = Article.objects.get(article_id = article_id_url)
        except Article.DoesNotExist:
            return JsonResponse({"Msg":f"The Given article_id: {article_id_url} is not exist in article table"})
        
        data = JSONParser().parse(request)
        serializer = ArticleSerializer(article,data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse({"Msg": f"The article_id: {article_id_url}is updated successfully" ,"data":serializer.data},status=204)
        
        return JsonResponse({"error":serializer.errors},status=400)
    
    elif request.method == 'DELETE':
        # delete article based on id 
        #check the article exist or not in articles table based on article_id and then delete based on article_id
        try:
            article_id_url = pk
            article = Article.objects.get(article_id = article_id_url)
        except Article.DoesNotExist:
            return JsonResponse({"Msg":f"the Article_id: {article_id_url} is not exist in Article table"})
        
        article.delete()
        return JsonResponse({"Msg":f"The article id: {article_id_url} is deleted successfully"}, status=204)
            




    


