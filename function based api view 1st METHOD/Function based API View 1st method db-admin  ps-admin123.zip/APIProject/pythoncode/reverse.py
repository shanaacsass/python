name = input("Enter a String")
print(len(name))
length = len(name)
print(length)
i=0
for n in range(-i,(-length-1),-1):
    print(name[i], "/t", name[n])
    i+=1
    