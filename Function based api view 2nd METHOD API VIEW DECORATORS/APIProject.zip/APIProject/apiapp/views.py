from django.shortcuts import render, HttpResponse
from .models import Article
from .serializers import ArticleSerializer
# from django.http import JsonResponse
# from rest_framework.parsers import JSONParser
# from django.views.decorators.csrf import csrf_exempt

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

# Create your views here.
def Index(request):
    return HttpResponse("It is index page")

@api_view(['GET','POST'])
def article_list(request):
    if request.method == 'GET':
        #we need to get all articles
        articles = Article.objects.all()
        # print(articles)
        serializer = ArticleSerializer(articles,many=True)
        print(serializer.data)
        return Response({"data":serializer.data},status=status.HTTP_200_OK)

    elif request.method == 'POST':
        # Post means we need to create new article
        # data = JSONParser().parse(request)
        # print(data)
        serializer = ArticleSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({"Msg":serializer.data},status=status.HTTP_201_CREATED)
        return Response({"error":serializer.errors},status=status.HTTP_400_BAD_REQUEST)
    

@api_view(['GET','PUT','DELETE'])
def article_details(request,pk):

    if request.method== 'GET':

        article_id_url =pk
        try:
            article = Article.objects.get(article_id=article_id_url)
        except Article.DoesNotExist:
            return Response({"Msg": f"The given article_id: {article_id_url}does not exist in Article table"})
        
        serializer = ArticleSerializer(article)
        return Response({"data":serializer.data},status=status.HTTP_200_OK)
    
    elif request.method == 'PUT':
        article_id_url = pk
        # First check the article is exist in Artcile table or not based on article_id
        try:
            article = Article.objects.get(article_id = article_id_url)
        except Article.DoesNotExist:
            return Response({"Msg":f"The Given article_id: {article_id_url} is not exist in article table"})
        
        # data = JSONParser().parse(request)
        serializer = ArticleSerializer(article,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"Msg": f"The article_id: {article_id_url}is updated successfully" ,"data":serializer.data},status=status.HTTP_201_CREATED)
        
        return Response({"error":serializer.errors},status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == 'DELETE':
        # delete article based on id 
        #check the article exist or not in articles table based on article_id and then delete based on article_id
        try:
            article_id_url = pk
            article = Article.objects.get(article_id = article_id_url)
        except Article.DoesNotExist:
            return Response({"Msg":f"the Article_id: {article_id_url} is not exist in Article table"})
        
        article.delete()
        return Response({"Msg":f"The article id: {article_id_url} is deleted successfully"}, status=status.HTTP_204_NO_CONTENT)
            




    


